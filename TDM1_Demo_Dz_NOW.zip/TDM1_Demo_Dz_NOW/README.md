# DZNEWS_-News_Application
DZNEWS is a mobile application for news in Algeria 
made in Kotlin
for now it is only front end part there is no connection to API or to a database 
I am working on it 
### First interface 

![alt text](firstInterface.png)

### Home interface

![alt text](homeInterface.png)




