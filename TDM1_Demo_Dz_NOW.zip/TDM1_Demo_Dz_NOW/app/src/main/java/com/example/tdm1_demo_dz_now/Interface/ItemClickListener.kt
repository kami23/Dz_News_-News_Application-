package com.example.tdm1_demo_dz_now.Interface

import android.view.View

interface ItemClickListener {
    fun onClick(view: View, position:Int){
    }
}