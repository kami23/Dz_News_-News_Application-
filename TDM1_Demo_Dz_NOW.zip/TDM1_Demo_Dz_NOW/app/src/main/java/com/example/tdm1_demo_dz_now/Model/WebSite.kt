package com.example.tdm1_demo_dz_now.Model

class WebSite() {
    var status:String?=null
    var sources:List<Source>?=null
    var articles:List<Article>?=null
    var categories:News?=null
}