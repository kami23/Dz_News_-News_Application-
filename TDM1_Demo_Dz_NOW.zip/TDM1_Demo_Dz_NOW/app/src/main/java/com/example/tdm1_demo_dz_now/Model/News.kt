package com.example.tdm1_demo_dz_now.Model

class News() {
    var status: String? = null
    var totalResults:Int=0
    var articles: MutableList<Article>? = null
}