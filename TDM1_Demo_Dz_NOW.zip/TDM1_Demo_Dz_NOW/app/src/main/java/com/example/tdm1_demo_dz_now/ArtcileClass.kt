package com.example.tdm1_demo_dz_now

class Artcile constructor(title: String,text :String,category:String){
    var title : String
    var text : String
    var category :String


    init {
        this.title=title
        this.text=text
        this.category=category
    }

}